const db = new Dexie("ImageStorageDB");
db.version(1).stores({ images: "id" });

const MAX_IMAGES = 6;

// Elements
const uploadButton = document.getElementById("uploadButton");
const fileInput = document.getElementById("fileInput");
const gallery = document.getElementById("gallery");

// Events
fileInput.addEventListener("change", handleFileUpload);

// Load stored images
loadGallery();

async function handleFileUpload(e) {
  const existingImages = await db.images.count();
  const files = Array.from(e.target.files);
  const available = MAX_IMAGES - existingImages;

  if (existingImages >= MAX_IMAGES) {
    alert("Limit is 6 images only.");
    return;
  }

  if (files.length > available) {
    alert(`Only ${available} more image(s) can be added.`);
  }

  files.slice(0, available).forEach(saveImage);
}

function saveImage(file) {
  const reader = new FileReader();
  reader.onload = async (ev) => {
    await db.images.put({
      id: crypto.randomUUID(),
      name: file.name,
      type: file.type,
      dataURL: ev.target.result
    });
    loadGallery();
  };
  reader.readAsDataURL(file);
}

async function loadGallery() {
  const images = await db.images.toArray();
  gallery.innerHTML = "";

  images.forEach(img => {
    const div = document.createElement("div");
    div.className = "item";
    div.innerHTML = `
      <button class="delete-x" data-id="${img.id}">&times;</button>
      <img src="${img.dataURL}">
      <button class="select-image-btn" data-id="${img.id}">Select</button>
    `;

    // Delete image
    div.querySelector(".delete-x").addEventListener("click", async () => {
      await db.images.delete(img.id);
      loadGallery();
    });

    // Select = immediately send to content script
    div.querySelector(".select-image-btn").addEventListener("click", async () => {
      const selected = await db.images.get(img.id);
      sendImageToTab(selected);
    });

    gallery.appendChild(div);
  });
}

// Send image to current tab
async function sendImageToTab(imageData) {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      files: ["content-script.js"]
    });

    chrome.tabs.sendMessage(tab.id, {
      action: "inject-image",
      dataURL: imageData.dataURL,
      fileName: imageData.name
    });

  } catch (error) {
    console.error(error);
    alert("Error injecting image. Make sure you're on a supported page.");
  }
}
